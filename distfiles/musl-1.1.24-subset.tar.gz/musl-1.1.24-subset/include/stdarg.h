#ifndef _STDARG_H
#define _STDARG_H

#ifdef __cplusplus
extern "C" {
#endif

#define __NEED_va_list

#include <bits/alltypes.h>

/* tcc 0.9.26 x86_64 has no __builtin_va_*; its runtime exports __va_start /
   __va_arg over the System V AMD64 __va_list_struct (see tcc-mes'
   tcc_x86_64_stdarg.h). va_list is a 1-elem array so a va_list parameter
   decays to a pointer; va_copy dereferences both sides. __va_arg's arg_type
   is hardcoded 0 (GP) -- the scaffold libc's documented FP-vararg limit. */
void __va_start(__musl_va_list_t *__ap, void *__fp);
void *__va_arg(__musl_va_list_t *__ap, int __type, int __size, int __align);

#define va_start(ap, last) __va_start(ap, __builtin_frame_address(0))
#define va_arg(ap, type)   (*(type *)__va_arg(ap, 0, sizeof(type), __alignof__(type)))
#define va_end(ap)
#define va_copy(d, s)      (*(d) = *(s))

#ifdef __cplusplus
}
#endif

#endif
